/* Allen Tran, Conner Knight
 *
 * Desc:
 * Model part of the process, makes the board from a 
 * json file and processes all the possible colors from files
 *
 */

#include "manager.h"
#include "messageManager.h"
#include "clientMessage.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <thread>
#include "ClientSocket.h"
#include <queue>

#include "thread.h"


extern "C"{
#include "array2d.h"
#include "jansson.h"
}

using namespace std;

#define NULL_CHECK(ptr) (ptr == NULL)

// Globals
queue<Path*> q;
Path* bestMove;
mutex lk;
int bestScore;
int movesExplored;
int numMoves;
bool done;
condition_variable cv; // need this to call ontify_one, notify_all

int main(int argc, char **argv) {
  // File arg check
  if(argc !=3){
    return EXIT_FAILURE;
  }

  cout << "started" << endl;
  // Setup the globals
  // q is empty
  // bestMove is empty
  // lk is init already
  bestScore = 0;
  movesExplored = 0;
  numMoves = 0;
  done = false;
  // End Globals
  
  // Unique lock to main thread
  //unique_lock<mutex> lck(lk);
  
  // Start up threads
  vector<thread> threads;
  //cout << "before thread making" << endl;
  for (int i = 0; i < 8; i++) {
    //thread tr(BFS);
    threads.push_back(thread(BFS,i));
  } // Each thread should shortly fall into wait

  //cout << "after threads made" << endl;

  // Setting up Socket Connection
  int errNum;
  Manager* masterPtr;
  int exit = 0;
  string hostName = argv[1];
  int serverPort;
  try{
     serverPort = stoi(argv[2]);
  } catch(...){
    return EXIT_FAILURE;
  }
  //set up the Client Socket with the given hostname and port
  ClientMessage message(hostName, serverPort);
  //sets up a manager for sending and recieving messages
  MessageManager msgManager;
  //writes a hello message
  string sent = msgManager.serializeHello();

  string recieved;
  cout << "first message sent" << endl;
  //sends message to server
  if(message.writeMessage(sent))
    return EXIT_FAILURE;

  // SEND-RECIEVE Loop
  while(1){
    //gets message from server
    if(message.getMessage(recieved))
      return EXIT_FAILURE;
    cout << recieved << endl;
    int check;
    //deserializes the servers message
    { 
      //cout << "make main-while-loop uniquelock" << endl;
      unique_lock<mutex> lck(lk);
      //lck.lock();
      //cout << "after lock" << endl; 
      check = msgManager.deserializeAction(recieved.c_str(), masterPtr);
       
      cv.notify_all();
      //lck.unlock();
      //cout << "end of uniquelock's scope" << endl;
    }
    cout << "case to after deserializingAction : " << check << endl;
    if(check == 0){
      // bye case
      break;
    } else if(check== -1) {
      // error in msg sent
      return EXIT_FAILURE;
    } else if(check == 1) {
      // helloack, do noothing
    } else {
      // else, send the board
      recieved.clear();
      //serializes the state of the board and sets it as a string 
      {
      unique_lock<mutex> lck(lk);
      sent = msgManager.serializeState();
      bestScore = 0;
      numMoves++;
      //while(!q.empty()) {
      //  q.pop();
      //}
      //vector<Moves> nextSet = applyMoves(bestMove);
      //for (int v = 0; v < nextSet.size(); v++) {
      //  vector<Moves> copy = vector<Moves>(bestMove->getMoves());
      //  copy.push_back(nextSet.at(v));
      //  bextMove.set
      cout << sent << endl;
      //sends the serialized state to the server
      if(message.writeMessage(sent))
        return EXIT_FAILURE;
      sent.clear();
      //repeat until either something goes wrong or user closes out gtk
      }
    }      
     cout << "got to end of loop" << endl;
  }

  // Last msg recieved was Bye()
  
  // End all tasks.
  // Set DieFlag True
  // Broadcast
  //lck.lock(); 
  {
    unique_lock<mutex> lck(lk);
    done = true;
  }
  //lck.unlock();
  cv.notify_all(); // threads should start finishing up

  // Broadcast to all threads
  int joined = 0;
  for (auto & th: threads) {
    th.join();
    joined++;
  }
  cout << "Collected : " << joined << "threads upon exit" << endl;
  threads.clear(); // vector destructs all objects
  
  cout << "Cleaning up Queue w/o lock" << endl;
  while (!q.empty()) {
    q.pop(); // q calls the element's destructor
  }

  // Free other globals that were malloc'd.
  // delete bestMove ???
  return EXIT_SUCCESS;
}
